package com.yofhi.storyapp.ui.maps

enum class MapType {
    NORMAL,
    SATELLITE,
    TERRAIN
}

enum class MapStyle {
    NORMAL,
    NIGHT,
    SILVER
}